// ==UserScript==
// @name         全网VIP视频免费看(支持爱奇艺、腾讯等)去广告，支持电视剧免跳出选集；全网音乐下载(多线路)；知乎视频下载；在线观看高清TV；必应壁纸下载等
// @namespace    coolhii_vip
// @version      2.1.4
// @description  [1]、全网VIP视频破解去广告，「支持电视剧免跳出选集，沉侵形会员体验，独此一家」，支持的网站有：腾讯视频、爱奇艺、优酷土豆等(注：解析调用第三方网站)；[2]、全网音乐免客户端下载(多线路组合)，支持QQ音乐、网易云音乐、酷狗等；[3]、知乎视频下载，方便保存；[4]、必应首页壁纸下载；[5]、在线观看高清TV；[6]、优惠券查询;
// @author       橘子爱哭、王超
// @include      *://*.youku.com/v_*
// @include      *://*.iqiyi.com/v_*
// @include      *://*.iqiyi.com/w_*
// @include      *://*.iqiyi.com/a_*
// @include      *://*.le.com/ptv/vplay/*
// @include      *://v.qq.com/x/cover/*
// @include      *://v.qq.com/x/page/*
// @include      *://*.tudou.com/listplay/*
// @include      *://*.tudou.com/albumplay/*
// @include      *://*.tudou.com/programs/view/*
// @include      *://*.mgtv.com/b/*
// @include      *://film.sohu.com/album/*
// @include      *://tv.sohu.com/v/*
// @include      *://*.acfun.cn/v/*
// @include      *://*.baofeng.com/play/*
// @include      *://vip.pptv.com/show/*
// @include      *://v.pptv.com/show/*
// @include      *://vip.coolhii.com/video/s*
// @include      *://pan.baidu.com/s/*
// @include      *://yun.baidu.com/s/*
// @include      *://pan.baidu.com/share/init*
// @include      *://yun.baidu.com/share/init*
// @include      *://item.taobao.com/*
// @match        *://music.163.com/*
// @match        *://y.qq.com/*
// @match        *://www.kugou.com/*
// @match        *://cn.bing.com/
// @match        *://cn.bing.com/?FORM=*
// @include      *://www.zhihu.com/*
// @match        *://www.zhihu.com/*
// @include      https://v.vzuu.com/video/*
// @include      https://video.zhihu.com/video/*
// @match        https://v.vzuu.com/video/*
// @match        https://video.zhihu.com/video/*
// @include      *://item.taobao.com/*
// @include      *://*detail.tmall.com/*
// @include      *://*detail.tmall.hk/*
// @include      *://*product.suning.com/*
// @include      *://*item.jd.com/*
// @include      *://*detail.vip.com/*
// @include      *://*mobile.yangkeduo.com/goods*
// @exclude      *://pan.baidu.com/share/manage*
// @connect      pcw-api.iqiyi.com
// @connect		 vip.coolhii.com
// @connect 	 cc.infopocc.top
// @connect      zhihu.com
// @connect      vzuu.com
// @connect      www.whatbuytoday.com
// @grant        GM_xmlhttpRequest
// @grant        GM_getResourceText
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_download
// @grant        GM_openInTab
// @grant        GM_info
// @require      https://cdn.bootcdn.net/ajax/libs/jquery/3.2.0/jquery.min.js
// @require      https://greasyfork.org/scripts/403428-dom-extend/code/dom-extend.js?version=805627
// @run-at       document-idle
// @compatible	 Chrome
// @compatible	 Firefox
// @compatible	 Edge
// @compatible	 Safari
// @compatible	 Opera
// @compatible	 UC
// @license      GPL License
// ==/UserScript==

(function() {
	'use strict';	
    var $ = $ || window.$;
    var window_url = window.location.href;
    var website_host = window.location.host;
	
	var coolhiiVIPVideo={};
	coolhiiVIPVideo.analysisWebsite="http://vip.coolhii.com/video/s?xxq=0&url=";
	coolhiiVIPVideo.judgeVipWebsite=function(){
		var isVip = false;
		var host = window.location.host;
		var vipWebsites = ["iqiyi.com","v.qq.com","youku.com", "le.com","tudou.com","mgtv.com","sohu.com",
			"acfun.cn","bilibili.com","baofeng.com","pptv.com"];
   		for(var b=0; b<vipWebsites.length; b++){
	   		if(host.indexOf(vipWebsites[b]) != -1){
	   			isVip = true;
	   			break;
	   		}
	   	}
   		return isVip;
	};
	coolhiiVIPVideo.addStyle=function(){
		var innnerCss = 
		`
		#plugin_coolhii_analysis_vip_movie_box{position:fixed; top:160px; left:0px; width:25px;z-index:99999999999;}
		#plugin_coolhii_analysis_vip_movie_box >.plugin_item{cursor:pointer; width:35px;height:35px;text-align:center;line-height:35px;background-color:#FF2C00;}
		#plugin_coolhii_analysis_vip_movie_box >.plugin_item_tv{margin-top:10px;}
		#plugin_coolhii_analysis_vip_movie_box >.plugin_item >img{width:20px;display: inline-block; vertical-align: middle;}
		`;
		$("body").prepend("<style>"+innnerCss+"</style>");
	};
	coolhiiVIPVideo.generateHtml=function(){
		var html="";
		var vipImgBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAABACAYAAACndwGZAAAE00lEQVR4Xu2cSagdVRCGvx8EwQEXoiJuJAiKAzhFVBIwCyMqgi6cQI0LFVQ0KxeufMGIIAriLCZOiL44LB0wohFF40Rc+JyNC104u4lBRSmpx+nYr+3Tfbrvvbnd167de/ec01XfrTrdXafqioKY2R7AGuAU4GTgqOKYGfj7N+Bj4BPga0lzRZuU/4eZHQg8DJw9A8Y3MeFt4BxJP2eTdoExsxOB95qsNoNjl0t63+1aBGNm+wM/zaChbUw6SNIPGZi3wp7SZqFZm/M8cK7MzDeemyqs+xL4FjgYODwybksDOqdFxvqGmBrK49Alpoerd4WDeQy4rERZN/Y2SS+GcFsBvFEBYI2kx+sAmdkjwOWRcVsl+d2wUsxsZF3MzMG4Q5QB2uhg3gWWl2iyStISTzCzq4AHK7Q+XtK2BMPeAU6KjNsg6cqENUbWxczOBF4oudaCg9kB7F34cIukVWXKmdmdwNqI4p8CJ0jaWWWYmR0JOJx9IuPWSrorAc44dPkCOKx4LQdjZWEUAxPC6mXg9Ijiz0o6P8EoH/N0xbjVkjYnrDOSLmb2Wlk4tQVzAOAhc0hE8TlJ6xKM8hj/z1NnmPedh5ukb2q8byRdxgomeI1vWk47JhdLmk+A414T87DNklYnrNFal7GDCXCuAe6NKP47cGriZvxRxTvZPZKuS4DTSpemYOr0mPnPY3vMzBteZ+AAJkJoADOAqQuepZ8PHtPQY6KvBM24tx/tL3nFd7X2q8VnNr1dTx3MJCCUrTmAiZAewAxgmgXh4DGDx/TQY8zsLOC8kDH8HNgkyU8DpyZTDyUzK8vY/QrcAdwu6Y9p0OkCmKrTgQ8ckKSndjecLoApza0WQDwTAHmifLdIX8A4jL9z4fXjpOn0CUzGwo81PLyqzrFG5tZHMJnRfjzim3PtUUobSn0Gk9n7QAD0VRsAsTldBnMrcGOisd/n9p+yg8LEZf4d1lkwkjxZth/gx62xw/6iwVuD9zzXmERhQqfBZLqa2TFuMFB7yBbmPAncIsnr6VpJL8DkAHkNoIeYg6qTBeCCtnB6BSYH6GrgZsBL4arkWkn31REs+7yXYNwQM7shHPzvVWH49ZLu/l+ACW/i64HjEgw+Q5I/7zSW3niMmR0a9peLEq1cV1bAnDjXPXJ89TGpF82Piyog5WuNq+plipf12kB/In61jT65fay7YMzMvWMjULWPZLZ8FoBsGAVI58GEyqyUfeTP3FPvL+OAEjb3bnpMooGbgpcslrOPUzq7x9QY6aW2nnqoKmIciVPfwHhfQ5YL/msky2sm9wnMQyFs/BRh4tIHMK+EsHlp4jRyF+gCGK+8LKv23h6AtHrXGRXi1MGEW2OxptdTDL65erHzVKQTYAIcr9v3xNR2SX7gNlXpDJipUii5+AAm8o00BbMg6eiufbuT0CcCZqcnor2L5NiSi66U9OYklOnKmqHLraxRZJuDiTVDeXeb5zqa9Dt2xeZaPUL7oKdNy1r/5h2Md+U/WrHSLILxHqeqXyCYczB7Ah4y3pA+CDwh6dKs73oZMNajzx4T3lfSjnxasa5lt8e2Jqu+64ZT/NEL72q9H7gkeanZGOgJsAsl+XvboiwBk/3TzDwpfUTozPfu/JRcbN8QfQi8HlKr88UawH8Agtc/Wn7LPVgAAAAASUVORK5CYII=";
		var shejiImgBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAdkElEQVR4Xu2dB9Q2RXXH70UUEQREBRtBECQ2QDDYYgERQaSr9C5IERSkCgpYACkKiCAoSBEbWFBEDYoaiYiCCgY0xo4tikIsMUjiP+f/5T6f+77fU3b33tnd2XfvORwOvDOzM/+Z33NnZ2fuqAw2KDAoMFEBHbQZFBgUmKzAAMgwOgYFpigwADIMj0GBAZBhDAwK1FNg8CD1dBtyLRAFBkAWSEcPzaynwABIPd2GXAtEgQGQBdLRQzPrKTAAUk+3IdcCUWAAZIF09NDMegoMgNTTbci1QBQYAFkgHZ2qmQBOEBFV1RNTPaPNcnsLCAC27aWqemWbAvf52QDeICInWRtP6iMkvQQEwFIi8iECIiIvHyCJxxTA60XkjfNK7h0kvQMEwP0Mjh0KnTdAEsgIgONF5E0TiuwVJL0CBMDSBsf2YzpvgCQAEgDHicibZxTVG0h6AwiA+xsc203pvAESByQAXicibylZRC8g6QUgAB5gcGxbovMGSEqIND8JgGNF5OSKWbOHJHtAACxjcGxTofMGSCqIBeAYETmlQpZi0qwhyRoQAA80OLau0XkDJCVEc8IxekK2kGQLCIBlDY6tSvTzpCQDJFPEA3C0iJzq0Dd7T5IlIAAeZHC8JKDzBkjGiAjgKBF5a4C+WUOSHSAAljM4tgzsvAGSgpgAjhSR0wL1zRaSrAAxOD4sIi9O0HkDJCIC4AgROT2BvllCkg0gAJYXEcKxRcLOW9CQAHitiJyRUN/sIMkCEAAPNjg2b6DzFiQkAA4XkTMb0DcrSDoPCIAVDI4XNdh5CwoSAIeJyNsa1DcbSDoNCIAVDY7NWui8BQEJgNeIyNtb0DcLSDoLCICVDI4Xtth5vYYEwKtF5KwW9e08JJ0EBMBDDI5NO9B5vYQEwKEicnaAvh8Rkf/luZuAsjr3xb1zgABY2eB4gVNwiMhVIvIyZznM3itIABwiIucE6HK1iGyvqn8F8AER2SmgzE5B0ilAADzU4NjEKTR/0XZS1asAcGl4gMQEBfAqEXmHU19m/5SI7KCq947KAvB+Edk5oOzOQNIZQAA8zODY2CnwfQbHRwsdN0Dy/x8BDxaRc536Mvs/GRx/nF8WgPeJyK4BzzhRVUfn3QOKq1dEJwAB8HCD4/n1mrE4119EZEdV/fiYjlvQkAA4SETe6dSX2a+3YBh3TyoLwGUisnvAs1qHpHVAAKxicDzPKeh/m+fgvHisLdTpViAc/2xw/GZWXwG4VET2mJWuxN9bhaRVQACsanA8t4RQ05L82TzHJ2eVs9AgAXCgiJw3S5cSf/8K3+VU9Rcl0i5KAuC9IrJX2fRT0rUGSWuAAHiEwfEcp4B/Ms9xTdlyFgokAA4QkfPL6jIl3ddsJe8nVcsCcJGI7FM135j0rUDSCiAAHmlw/KNTuD8YHNdWLafvkAB4pYi8q6ouY9J/w+D4Qd2yALxHRPatm7+Qr3FIGgcEwKMMjmc7Bfu9Tas+U7ecvkICYH8RuaCuLoV83zY4vustC8CFIrKftxwRaRSSRgEB8GiD41lOoe4xOLjc6LK+QQKAg5CDMcJuN0DuiCgMAD0aPZvXGoOkMUAAPMbgeKZTnd/ZtOo6ZzmLs/cFEgCvEJF3R+li5URDwncivht5rRFIGgEEwGoGxzOcqvzWPMfnneUskT13SABwjs+5fgqLhoTfY/hdxmvJIUkOCIC/Mzie7lSDa+/8CPgFZzkTs+cKCQCuEnG1KKVFQ8LtLtz24rWkkCQFBMDqBsdGThX+w+D4krOcmdlzgwTA3iJy8cyGxSSIhoQbJrlx0mvJIEkGCIDHGhz/4Gz9rwwOfsVtxHKBBAA/wvFjXJMWDQnPo/BciteSQJIEEABrGBxPc7aaX205rbrBWU7l7F2HBMCeInJJ5YbFZIiGhMd9eezXa+GQhAMCYE2DY0Nna39mcHCLQyvWVUgAcI8T9zq1adGQMJoKo6p4LRSSUEAAPM7g2MDZyjtt/f2rznLc2bsGCQDukuVuWa9xgD/JWUg0JIzHxbhcXguDJAwQAGsZHE91to77fXiCj/t/OmFdgQTAbiJyeYAoiwa29VfXIGG4U4Y99VoIJCGAAFjbxF7f2aof2bTq685ywrO3DUkgHP9qGt8B4IkdhYRXLfDKBa+5IXEDAuDxJvJ6ztb80DzHLc5ykmVvCxIAPKHHk3peIxz0zt8ZFdRhSHiTFW+08poLEhcgANYxONZ1tuL71nHfrFqOeS9e1P3vVfPWSd80JAB2EZEr6tR1Xh5uPOSK4GI4MoCEdyHyTkSv1YakNiAA/t7geIqz9t8zOG4tW44tBvCFjtvleVyXxi/tXPE6UFV/WbasOumaggQAAyAwEILXZu7K7bAn4VXTvHLaa7UgqQUIgCcYHE921vrfDI7bypYDgJd0Eg6umI0znkvfRFX/pWyZddKlhgQAQ+gwlI7XqC09x8wt6x2G5EQROcErRJ2t8pUBCRSRrp7zYc6LS1nF6caqqvrrUgXXTJQKEgA7isgHa1armI1wUGP+EJWywP4NWQIOrA+37FML1qu01QEkiuZKsY9qfDn+hKpWudiztGjFhNGQAODy64dqVWZuJk5Z6TlKwzHKHjgoXZAE1qPyj/FIi8qAMCMAxit6Q0AnloLEcc5hPVUtPX2r255ISGzqWrcqo3yEg7+WfL+rZYGDsxYkgc/n1JJa8D2sstUCxCCJenmaCokzZM0eqhrxYW2msIGQzHzWjATfMs9RG462PUkgHJXfcedrWxsQg+RNInK8t0dFZCwkAdHHD1fVxkL7dwASLpNzWhW25B04WEt5ksDnVV4dHTeOXYAYJFFr1XMgCbpIcmNV/WIAwKWLaBESwsGpBL8phVrgoJ0KSeBz+ANBLehNXeYGxCCJ+uq5CBIA/ILKMr22iqrOjALofcj8/C1AwtA89BzhcDQ13QqEo/ZH5yQepCBgGCRBa95HqmpTF1IuoW2DkLjjVpX9gQgcxHM8SWC5jN1Fz0FNQizEgxQgOVlEjg2pma+Qy1U1Ii6sqxYNQMJ9a/QctYO6VW1g4GAe7ShmFRhY3LurOMlevlBAbLoVtROzat+N0n/MYsjyjpDWLSEkhIO/lhwYjVowJKy7Fw7uAqcWN0cLEQ6IQXKqiBwdXdkS5fFSl5eqKiO9d8YSQMKBQM/ROByF2ULUVnlvPyWDgxVLAohBEnXwpayAjLLI6OMMSdo5C4SEcPDXkgOjVQv0JHXb8WPTItn5oWSAGCSniciRdVtfIR9jZREOBpbrlAFYyubYOwRUjAOBnqN1ODrgSRo5eZoUEIMk6pzxpPHFiCf8Ra20xd1uteLcl0eE+Ut0W/TLLoClbV/V9gFw8Agy4WBdO2UteJKfWp/flFqI5IAYJFERK+brQYEIBwUrZQCWt5Nq41bbOE17naq6TzUCuL95jm1LVWx6otr3cwQ8u1QRDULSaECPRgAxSM4UkcNLqV0uUeUvx9aJPLo6K7DENqr6iXLVWDIVgGUMjq3rllHIxx8Beo7Kl9cEPLtSEQ1AwlBQ/EG8sVLFHIkbA8QgiQoQtsTZ6lkaVOy8u1R1dFJxVtFz/g5gWZtWbVUp4/jElT1kwDNdRVTUucqzfm5wNBonrVFADBJuHnxNFWUmpC21Vd6eWWdJsnT5o/oBWM7g2DKgfYwJRs9RevoY8MyQIhJAwgib9BxJT4mOa3zjgNiAjYrHOnMQOzrrs6q6edkRY+82/CK8Rdk8U9IRDg4IzrezNIfu89vLxRdq0Xj4WVakFUAMkrNF5NCA3p8IibOTfq+qK5apH4AVzHOUBmpKuZxf03PkDAdXB/ljQc/tMQYuJxxf9hTiydsaIAZJsvD3TjhYvdtVdWZQCgArGRybeTrC8hIODgi+jGZpAKgZ4WBgD4/xygtq0VhU/3GVbRUQgyT8IpUAOFi1S1SVd29MNAArGxybekaC5eXLJwcEX0aztEA4GGyDWiS/D2aW0K0DYpCcKyIHz6psib8zoMSVQbtD91HViXdvAHiowfGCEvWalaQPcDA+Gj0H46V5jOd3CEejB90mVbgTgBgkUffWRUQtv1JVGV1krNlXeEYe2dgzEiwvV2Y4ILhSk6UBiILjLtMi2TV7VQXuDCAGyXmMjFi1EcHpZx0LXdU8x/MCnsuVGb6Q5wwHw87SczAMrcc6Bwcb0ylADJKoa4LrdNYsOB5pAd2eW6fweXlq7SELeG5YEQCi4OAmU3rR68MqF1RQ5wAxSKIunK8i0yw4HmWeg/GAvcZlS3qOShssvQ+NzA+A0fzpORjd32O8955whF/t7anUKG8nATFILhCR/SMaWaKMWXA8xuB4VomyZiUhHBwQXOPP0gLhuNu0+FxXhegsIAbJhSKyX2LxZsHBe94ZJ/eZAfXgmj49R85w8JIkeg5emuSxewyO6zyFpM7baUAagGQWHLzKmnA8PaAjCAc9Bz+AZWkAuAuacPC6PY/9p2nB4wWdts4DYpC8W0ReEazkLDh4lTWXcr33vLPa/OBFOJJGmw/WZ05xgXDwSDS1+GzK+kaVnQUgBsl7RGTfoIbPgoN3j9BzeO957wscvLWYnmPSnSxlu+UPBsdnymZoO102gBgkF4nIPgGiTdvgyLk14fBeZc1q8mswfy0bj+4YoNGiIgBEwfFH0+LTUXVropysALEOu1hEpu6RKincEpDYnYuEw3tbL6vAr8F8Ic8Zjg3Nc6xZUtNJyf5kcFzrLKfx7NkBYpBwj9ReAWothsTuXOQ7h/dC0hEc9Bz8OpylAYiC478MDsYsy86yBMQguURE9gxQfLTBkZ7DeyEpq8OvwfQcOcPBdy++c3ChwmN/Njiu8RTSZt5sATFILhWRiBi8ERscR3DQc3QuPlfZQQYgCg5Gt6QWnyz77C6myxoQg+QyEdm9A+JyqwQHBLdOZGkAuKRNz8HvPx6717SoHRnG8/DIvNkDYpDwmrXdIoWpWFYf4NjI4Fi9YtvnJ+8NHGxYLwAxSBjvaldn59bJzn1E9BzcV5SlAYiCg3fUU4ursxRiTKV7A4hBcoWI7NJg5/QBDm6j4bSKe848dp/B8XFPIV3L2ytADJL3i8jODQjNTXb8teSmuywNQBQc/2Na8G6WXlnvADFIPiAiOyXsqT7A8QzzHKs5deJFRfyh+KiznE5m7yUgBgm/a+yYQHXuQOWA4I7ULA1AFBx/NS0+kqUQJSrdW0AMEn4Znxh8oYQ+85NwByrh6OQlPWXaA4DnWvjOwUNgHoNpcZWnkK7n7TUgBgkHw8sCOqIPcPBEJH80vHBQTv5QMMRSr63XgAAgGATEa9yezQHB7dpZGgDCQS0eHdiA3kPSW0AGOP6GAYBnGxwMPBFtvYakl4AEwsGzCxwAPMuQpSWGY6RJbyHpHSADHHM8B0MUcVrFeF6prZeQ9AqQQDh4sIcdzoM+WRqAJuHorSfpDSADHHM8x3PMczyiBbp75Ul6AUggHDz1xg7mKbgsDUCbcPTOk2QPSCAcPPVGOHgKLksDwJjBfOdggO22rReeJGtABjjmTKsYbZ4fASPg4AfAiI+r2UOSLSCBcPBIKDuSR0SzNACEg55jlYAG8Dz9hwEQkpcGlJc1JFkCMsAxx3M83zxHBBw7qyo3eTIe1lJ2W9f2CxmS7AAJhIPnpfnrxiOiWRoAwkHP8fCABuyqqjxLs9gA3M8g2S6g/Cw9SVaADHDMGby8/o1wPCxg8O6mqjyNuYQBWNog2TbgOdlBkg0ggXDwvDQ7iuenszQAkXDsoaoMejHRANzfINkmQLCsIMkCkEA4eF6aHcTz01kagE3Mc/CWXa/tpaqMLTbTADzAINl6ZuLZCbKBpPOADHDMmVZFwrG3qjI6ZWkD8ECD5CWlM01OmAUknQYkEA4GE2CHMLhAlgaA97HznWPlgAbsq6oMAl7ZACxrkGxZOfOSGToPSWcBGeCY4zk2taXcCDj2U1XetVLbADzIIHlx7UL+lrHTkHQSkEA4GGmDHcDIG1kaAMJBz/GQgAbsr6q8rcttAJYzSLZwF9bh47udA2SAY47neKF5jgg4DlBV3hwcZgAebPBuHlBoJz1JpwAJhINhaCg4w9JkaQAIBz3HSgENOEhVzw8oZ4kiAKxg9XxRQPmdg6QzgAxwzPEcm9mgWzFg0B2squcFlDOxCACsJ/duEWqvdQqSTgASCAdjNFFgxmzK0gBEwnGIqp7bhBAA6OkICd+ZvNYZSFoHJBCOK1U1Mkict5Mr5wfAaQqnVZy2eO3VqnqOt5Aq+QHwXYmQcEnaa52ApFVAAuFgZ3RC0LqjAgBfdHmeIwKOw1T1rLp18eQDwC/8hJwfNb3Wep+2BkgwHKOOaF3QOiPC4OCg4qqQ1w5X1bd7C/HkB8ANlGwP94x5rdU+bQWQRHBkCQkAfkeg54iA4whVPdM7IiPyA+AWfE63eJjLa61B0jggieHIChKDg7+0y3tHkIgcpaqnB5QTVgQAHuIiJDwr77VWIGkUkIbgyAISANymQc8RAccxqvrWaSMQwN42UHlRJ+PzflFEblVVXoOdzAAw9BB/BBhtxWuNQ9I0IN8WkSd7VaqQv3FBy9TN4OCg4XYNrx2rqqdOKgTAE0WEEEwKwnCTqvK+kGQGgJEd2V4Gs/Nao33aGCAAHici3/eqUyN/o4LOqh8A7oLlYOGGP68dp6onz4CDz3rSjAfdqareOwqnPgIAA2ezLgyk7bXG+rRJQHglGq9Ga8MaE3Ra44LheL2qvjkAjlERZ6jqkSk7BwCndoSEVzF4rZE+bRIQrq4c7lXFkb8RQacMWB4y4uDgeQqvnaCqbwyEY1TUOqr6PW/lZvxI8PIevrhHTOuS92mTgHyp5mrGN0RkmRLThDL9mlzQcZUAsJW9kEfAcdK0F2t75ygzrRpX1V1UNbmXB8DpHOvIW3a9lrRPGwHE9un8osav5/Uisp+I8Khn3U6f3wFJBZ3/MIODdWcbomwsJE44WLfGPjICWN36dKMAUZL1aVOAcAMe7/irYrxNdutR3KqAzi8+O5mgxYcAYIADLuVGwjF6xBxIgvTZWFW5/NuIAXisQcKlZ68l6dOmADlORCa+UE5Q5i2qevy8Acclyyw8icHBunJ6mMpOVNWTguBgHVdR1d+kquy4cgGsYX36tIDnhkPSFCAMt1M1ptJ2qsp8cyxwMLDccEFZKAC2lZ4jJRwjXUbfOGYt5c4af6eo6utmJUrxd/sEwB+TDQLKD+3TpgD5uYhUvUByNVX92YRfnc56EoODnc04UrnYN7mA0uZdjADWMk/y1ADRwiBJDggAus6vV2z0Lao61eV20ZMAYHhOeo6c4LjdPOkdFfsoPDmAtQ2S9QMKD4GkCUAOEpF3VmzwBap6wKw8XYIEAAM8Ew6G6czFOgPHSDAAjzdI1gsQ0Q1JE4AwQBk3ylWxV6jqRWUydAESg4PTKgZ6zsU6B0cBknUMknUDxHRB0gQgdTYorq+qt5YVp01IAPD+DHoOLxwcsDxTf0LZdjvSdRaOAiRPMEgiNrfWhiQpIPbF9CcVO/LHqsqlv0rWBiQGBz0H79Hw2OIBC+AkEXmDp7AZeWvBYQeguFLGl2guntyuqknfW9ro0/napQakzgbFq1S11v14TQoKYAfzHGFwFH49uc/q9QkgqQwHAJ5X4fLvsWPq82URYYT4HyaoK5fLW1+tTA1InQ2KR6vqaXUFb0JUg4Oeg9eUeWzigAXwJhGZ86HU8yD+4lddrTIt32deY9rjN1BVLhWHWRP9WKayqQGps0FxU1X9fJnKT0qTUlwAvNiS7xzJ4Ch4Eu4+4C4Er9WFo+yuBd4r/xhVvdtbUeZP2X9V65cMELtL4ncVNyj+QURWjxA6hcgGBweNV7fSAxbAW2yKU7Vv56efugu4mLimdh9RVfetuDWfPUmb2i/nowK9HT2x0+w+i89V7NUvqGpEPKVFj40W2zyHV7PScBQ8SWOQODT7raq67kt0PHvcMHPDwUK9nT0NkDobFE9X1aMqQjU1ebDo3qpVhqMACY/WjntRrlqniZ4kQKsnqup3qlYoxY+ZqvJQlttSAlJng+KiS+zdrZpXQEDHR1SpNhwFSE4RkWMCKrNoF3DAtGp+VdZS1R9UrV9w/4R4jiamWHU2KK6tqkkCOwR3QtUx4IajAAkjmBxdtQJj0i+GJEibbL5fVdEuiQcB8BQRua1KRZheVSP230yb9kWuq5dtXhgcBUgYAytiKsqt8pyKlF2tmtbms1T1sLKidHlaVWxDKkBeKSLvqiKWiFysqvtWzFM5edCvZdnnhsNRgITfiiKikLCO3rMk32IcXlW9p6wwwf0QOq1qApA6GxSTX/RSGFxNeJJkcBTawVCjR5QdlInS8S6W7ccdbpv0vFzgYP1TeZA6GxSfqapfTdSJSxQb3Enzy08ORwGSM0TktU3pNu8594rITn2FIwkgAFYVkV9V7DC+0K+pqn+pmM+VPBEkjcFRgKTOlh6XdiLyR4PjU2ULCtY72bQq6RTLzkbw+uUqdrWq8jRe4xbcaY3DUYDkbSJS6SXZITa3lHBJ/rqyZQTr3AgcqTxInXnx1EiBZTuhTrrAjmsNjgIkvDjnNXV0qJDn1wZH6fBAgRqzmo3BkQqQOhsUt1LVayp0UkjSwI5rHY4CJLx67dUhAi1ZCM+B0HN8pWz5gRo3Dkc4IAD40v+nihsU+aK3hqr+sqzoddMBWFNEGAyi+I/3ZqfOwFGA5GwRObSuThPy/ch+vW8uW27ucKQAhKHtbygroKW7QVUjLleZ81gADJ7AOEtFGCKObxaf0zk4CpDwhttDKvbFpOQMaM2pTRbHoIPavKiY0GVeAPxwVfWw0zmq6p4SWGh9HgfdUEQYypJgcEUtlXUWjgIk7xCRVwUIUHqrPJ/VB88x0iwakI+JSNXVKB7ZvLRqJwJg7KQRECMv4T3+WrYanYejAMm5InJw2YZNSVcKkj7BkcKD1NmguK6q8sPiRLO7tzldGv1DIPg+0YZlA0cBEsYlY3wyr6W8emF+3RpdrZokTJgHsah4VS9f+a6qMrzLHAPA/0fvUATC+zLtHRzMnx0cBUjOE5EDA0RIdfVCsWqdgCPUgwDYU0QuqdgB7xcRbmwcgTCCIvplumK1xibPFo4CJOeLyMyIlSXEmnOepG/TqmL7Iz3IBSKyfwlxi0k+bXCkfJmuWKV+wlGAhLus+aPkteirF1ifzniOkTiRgNTZoOjtpCbyZ+85xkxh6/yYjdOapxIZqMG7Xb6TcIRNsQCsKCKlzwI0MaqDntE7OAqe5EK73i5IKlcxnfMcoR4EwBYicq1Lou5l7i0cHYOks3BEepDoKIBt4sIt97eICCPMJ40922YjC5C8m21tqS6dhiMSEN5Gu3FLInsfyw143F9EKPjvm1X1Lm+hOeUH8B4RSX7ceZ4mnYcjEhCGnoy4A7yJccV71xeBQChUlf+94A0A72PZpyEhsoAjBBAA3PtUeodnQx0wegxvbC16h5tUteppx4ar3N7jANSJJVC1wtnAEQUId4xy52gXjC/WI+/wNVX9WhcqlVMdALyXVxokqnNWcEQB8kEeokkk6LRif1/wDgThRlXlXrDBnAoA4I4I7oyItOzgiALkpyKyWqSSE8pixEV6B96YSxhubOCZC/YRALjDeo8gAbKEIwoQxkWKNp4y5KrSIs9gQNwZ/ZChvOkKALhMRHZ36pQtHF0ChIN/kWcoAPFXZ8cM2QMUAHC5iOxWs6is4YgChKFfNq0oIKdKRRh+XDH/kLxBBQDwGrZdKz4yeziiAHmsiPBA/yRjmJjFMNh06b6KYg/JW1YAwBUiskvJavQCjhBAWAiAZUSEF7zwXAeNWzRG7w6V74so2QlDsoYVAMDzOzvPeGxv4AgDpOF+Gh7XogIAPsCQoxOq0Cs4BkBaHGg5PxrAuG9fvYNjACTnUdpy3QHwKuyXWzV6CccASMuDLPfHA+DNVFdGXZjZRT3Cjtx2sXFDnQYFvAoMgHgVHPL3WoEBkF5379A4rwIDIF4Fh/y9VmAApNfdOzTOq8AAiFfBIX+vFRgA6XX3Do3zKjAA4lVwyN9rBQZAet29Q+O8CgyAeBUc8vdagQGQXnfv0DivAgMgXgWH/L1W4P8A02uBfSYroicAAAAASUVORK5CYII=";
		var tvImBase64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAR8UlEQVR4Xu2deaxuZXXGn6f6hzUgxjjSSDAYsWq0VeFig0bQaLFqsUbAiUTUghQHAhRBDKIIVMERNEKwTjigxYqKOF8rCohQiopjiRCLGkXEGTU+Zt3uS84995zz7XfY4/e8yfnnfmutd+1n7d/d+1vf3u9LeFgBK7CuArQ2VsAKrK+AAfHZYQU2UMCA+PSwAgbE54AVyFPAV5A83ey1JAoYkCUptA8zTwEDkqebvZZEAQOyJIX2YeYpYEDydLPXkihgQJak0D7MPAUMSJ5u9loSBWYLiKT7AXgYgHsA+AqAa0j+aknq2ulhStqx0Tb0va7R9n87nXSg4LMDRNIOAF4L4LBVmv4AwBsBvInk7wfSe/LTSjoUwPEAdll1MJ+Kfyd55eQPcsUBzAoQSfcH8M0FBboKwLNJXjunQvZxLJLOB/C0BXP9I8kL+8injznmBsi3AOzeQrivR6FJhr1HCwVawhGRfkrybi1CTsJkNoBIegWAExNU/1oDybcTfJbSNAGOrfqcRDLqMfkxJ0A+DGD/xIpc00DynUS/pTHPgCO0+STJv5+DSHMC5GYAd84oytUNJN/L8J21SyYcockvSO40B3HmBMh/A/ibzKKEb3wnmWWrMkeTAjhium+QfFDOvGPzmRMgb12jtZuid7QnDyAZff2lHoVwhHbnknzeHEScEyB/F/e+AOJ3kNzx1eZK8v3cAFP3qwBHSPBYkp+duhaR/2wAiYORFD8OxpWkZFzRQHJ9SZAp+laC4wySR0/x+NfKeVaANJCktnvX0uXy5nbrhrkUetFxVILjgyQPWDTXlD6fHSANJK8E8PLCQlzWXEniEZVZD8OxfnlnCUgDyasAnFB4Zl/aQPJ/hXFG6244Ni7NbAFpIDkZwMsKz84vNZD8sDDO6NwNx+KSzBqQBpJTABy3WIoNLS5pIPlRYZzRuBuOdqWYPSANJKcCeGk7Sda1+q/mi/uPC+MM7m442pdgKQBpIDkNwLHtpVnT8gvNleQnhXEGczccadIvDSANJK8BcEyaRNtZb24g+WlhnN7dDUe65EsFSANJvG1Y+kPW55rbrZvSJR/Gw3Dk6b50gDSQnA7gqDzJbvOKRyniAcd4injUw3Dkl2cpAWkgeR2AI/Ol2+L5mQaSnxfG6czdcJRJu7SANJC8HsBLyiRELFYQTwHfUhinurvhKJd0qQFpIImVTl5UKGU8RRy3W78sjFPN3XDUkXLpAWkgeROAFxZKenEDyeBrbxmOwkqucDcgjRiS3gzgiEJpL2put35dGCfb3XBkS7emowFZIYukswAcXijxx5sryW8L4yS7G45kyRY6GJBVEkl6C4AXLFRuY4OPNleS3xXGae1uOFpLlWRoQNaQS1Lp++0RNVYXjO7WrUkVyTA2HBmitXQxIOsIJeltAP65pY7rmX2kud36Q2Gcdd0NR1fK/n9cA7KBvpLOBvD8whLEgnZxJfljYZzt3A1HbUW3jzcKQCTtCiD+xjjiua1/KEzsiwDiXfk/FcZZ6R7LrD66MF48eHlSYYyu3G+MrRW6+I8lJeHeAZG0KZaFaf7GDEaKjrbtToFYOCPWKovvdJtJxiJ/vY1eAJF0++bhwEMAxMY2HlYgV4HY3uKdAGJ5oeq3rauT6hwQSbEMTNym7JGriP2swBoKxPplp5OMPUs6G50CIqnGq66dHbwDz0KBs0nGrledjM4AkXQBgKd0krWDWoFtFbiS5MO7EKUTQCSpi2Qd0wpspADJ6udz9YCSouNwH5fSCgygQPUrSVVAJMVrqPsOIIyntAJbFai6PnA1QCTVWOrTZbYCNRQ4mWTp2sxb8qgCiKTYWTZWRJ/Ftls1KuQYgyoQrz9vIlm8QWstQGq8bDSoop58dgqcSbL0LdHyK4ikXQAs3WYzszud5nlAu5VuqVd8BZH0DADnZer7MwDxLnfsWR77ccxp3LF5rCYu8129XdjHHEPVJB5J2hPAgQXb6h1KMp7Izh41ADkXQDxjlToCqmNIzm5bgVQhbL++ApIeAOAcALEHZeoo7mjVACQWcr5rYuYXk9wv0cfmS6yApDcAeHGiBDeTvEuizzbmRYBI2jE2jU9M4CqSD0v0sbkViE1aYyXLxyRKsXPJXUopIDlf0I8iGct+eliBJAUkxYozsfJMytibZOwSljVKAXkIgKsTZz6I5AcSfWxuBeIK8ggAX06U4mCS7070uc28FJB45fPziZPvQzJe9fSwAskKZDwIexLJeN05axiQLNnsNJQCBmQo5T3vJBQwIJMok5McSgEDMpTynncSChiQSZTJSQ6lgAEZSnnPOwkFDMgkyuQkh1LAgAylvOedhAIGZBJlcpJDKWBAhlLe805CAQMyiTI5yaEUMCBDKe95J6GAAZlEmZzkUAoYkKGU97yTUMCATKJMTnIoBQzIUMp73kkoYEAmUSYnOZQCBmQo5T3vJBQwIJMok5McSgEDMpTynncSChiQSZTJSQ6lgAEpUF5S7L8eK638VUGYcL0XgFj39i8B/AnAb5oF8mIt4dwRW2HHGsSfzt3rW1KsVxuL7t0TQOwX/g2SsbLlYEPSDgAe3Pz9AcA1AK4l+esukjIgGapKehaA7LWPMqYsdfkUgFe2XdCsOQlfC+CwNSbudJfXjQ5U0iObdXNjf5iV48b495Lldtab14AknnqSYs2jExPdxmL+JJIfW3AS3hfAdxcl3MUGlgvyaqN78eLRq3MwIIvOhBWfS3oggK8nuIzN9CaSGy78LemrzW3VotyfQ/Idi4xqfC5pU8J2FY8nGVfMKsOAJMgoaQ47W627FKuk/QF8uKUk3wewF8kft7TPNpN0IYAntQxwCcm4FasyDEiCjJLii2B8mZ7yeC/JZ651AJKOB/DqhIM7muQZCfbJppL2BvDFBMfrSO6WYL+hqQFpqaSkewO4oaX5mM2+SzK6U9sNSR8B8OSE5K8m+bcJ9smmkmJ19Vhlve24leQd2hovsjMgixRa8bmkaMEWrS+cMF1XpptJ7rMOIKknY4R5Jsn3dpFs859StKpTdjP+DsnVXa7s9AxIgnSSYhuFAxJcxmj6IpLxXWqtK8jzAaTusfcJkk/o4kAlHQvgtMTY7yMZ+1hWGQYkQUZJj282AU3wGp3pTiTX3KVL0sMBXJGR8b4kU7elWDiNpP9pfhBcaLvC4HCSb01x2MjWgCQqOfGryJEkY++9dYekDwF4aqIsbyf53ESfDc0lHQTgfYkx4zvig0nekui3kR5KjLXc+4NI+gsAbwRwRKJwQ5svhCMSlPRPAP4jMdnfA3gQyYU/MLaNm9ja3Rr2NJLHtZ2jjZ2vIG1UWsNG0v0BPB1A3HbFr8+/TAgVXZZ4vill/AjA71o67ArgBwC+B+ACAO8g2To/SV8BsEfLubaavZrkCYk+a5pLii2Yc/b5i6tHfKmvNgxINSnbB5I06q3kJL0EwOvbH9EWy+sB7E7y1kS/7cwlnQngXxLjrPv7TmKcbcwNSIl6mb4TAOTuzVOy90g8xCNIpu4Ku/qEjCej41YtnmxOGU8k+fEUhza2BqSNSpVtxg5IHK6k2Dr7yMRDv4xk7AybPSQdA+A1iQGqPl6ycm4DkliJGuYTASS35bs/yfhFPmtIuhbAXyc6V23tGpBE9WubTwGQ5iqS0/K9gGRqm3iLxJIOBPD+RL2rt3YNSGIFaptPCJCclm/I9dCctxglXQRgv0S9q7d2DUhiBWqbTwWQ5n/1nJbvWSSTfieStBeASzO0rt7aNSAZVajpMjFAclq+8Uv2biRvaqubpLcAeEFb+8auk9auAUmsQm3ziQGS2/I9nuSpbbSTtHPzKsHt2tivsOmktWtAEqtQ23xKgDS3WTkt32+RbNWNkvSvAP4tUefOWrsGJLEStc0nCEhuy/dZJM9bpJ+keCQm9S3Azlq7BmRRxTr+fGqANFeRnJbv50nuu5Gckp4G4PxEyTtt7RqQxGrUNp8oILkt30eRXPedckmfBhAL8KWMTlu7BiSlFB3YThGQ5iqS0/J9D8lnryWjpD0BXJ4hcaetXQOSUZGaLhMGJKflG9LtSjKe9t1mSDoHwPMSte28tWtAEitS23zCgOS2fE8h+bJVJ168D/PDDG07b+0akIyq1HSZKiDNbVZOyzcWl7sXydteX5UUwJycqGsvrV0DkliV2uYTByS35XsYybdt1VJS3HLtkqhtL61dA5JYldrmUwakuYrktHyvIhlbKcRTu7Gy43sSde2ttWtAEitT23wGgOS2fJ9A8hOSvgDgUYm69tbaNSCJlaltPnVAmqtATsv3PwGcDuCSDE17a+0akIzq1HSZCSC5Ld93ATg4Uc9eW7sGJLE6tc1nAkhuyzdHzl5buwYkp0QVfeYASHObldPyTVWy99auAUktUWX7GQGS2/JNUbT31q4BSSlPB7ZzAaSg5dtW1UFauwakbXk6spsZILkt3zbqDtLaNSBtStOhzZwAKWj5tlF4kNauAWlTmg5tZghIbst3I5UHa+0akA5P/jahZwhIFy3fwVq7BqTNWdyhzdwA6aDlO2hr14B0ePK3CT1TQGq2fAdt7RqQNmdxhzZzBKRiy3fw1q4B6fDkbxN6xoDUaPkO3to1IG3O4g5t5gpIpZbv4K1dA9Lhyd8m9MwBKWn5jqK1a0DanMUd2swckJKW7yhauwakw5O/Teg5A1LQ8h1Na9eAtDmLO7SRFNtGp+4pfqeUrZw7TH9haEk5Ld/RtHYNyMISd2sgaYfEfdUvJRl7h09mSEpZ2GFUrV0DMoLTTNIpAI5rmcpeJHOW6GwZvr6ZpCcC+GjLyIeQ/PeWtr2aeZfbXuXedrKWCzc/l+TbB0wze2pJrwBw4oIAm0nukz1Jx44GpGOBF4WXFNuOxfZjq8evABxF8uxFMcb8ebO9wbEAtqyJtWLcCOAckgHRaIcBGUFpJD2uOYEeAuC3zYrnl+fsFDuCw1kzBUkHAXgkgLsB+CSAi0jmrM3b6yEakF7l9mRTU8CATK1izrdXBQxIr3J7sqkpYECmVjHn26sCBqRXuT3Z1BQwIFOrmPPtVQED0qvcnmxqChiQqVXM+faqgAHpVW5PNjUFDMjUKuZ8e1XAgPQqtyebmgIGZGoVc769KmBAepXbk01NAQMytYo5314VMCC9yu3JpqaAAZlaxZxvrwoYkF7l9mRTU8CATK1izrdXBQxIr3J7sqkpYECmVjHn26sCBqRXuT3Z1BQwIFOrmPPtVYGpARLL4lydqNBBJD+Q6GNzKwBJjwDw5UQpDib57kSf28yZ6xh+knYBcH1ijFh87XWJPja3AnG+HQ7grEQp9ib5pUSfaoDsCOAXiZNfRXL1qn6JIWy+jApI+gyAxyQe+84lC+IVXUGaq8hPANw1MemLSe6X6GPzJVZA0hsAvDhRgptJ3iXRZxvzGoCcC+CQjCTOA3BMCd0Zc9plYgpIekCsGQwgZ7uJD5I8oOSQawDyDABxsueMnwG4GMDXAFyWE8A+s1XgfgD2BHAggNi/JWccWrrYeA1Acr6o5xysfaxAqgK7kbwu1WmlfTEgzfeQNwM4oiQR+1qBygqcSfKFpTFrAbJ7s0XATqUJ2d8KVFDgFgCbSH67NFYVQJqryKsAnFCakP2tQAUFTib58gpxUA2QBpLPAti3RmKOYQUyFSjuXFX/DrIyoKT4UnSfzIOzmxUoUeBKkrHldbVR9QqyNauMB8qqHZADLa8CJKufz9UDroDkAgBPWd5y+ch7VKD6lWNr7p0B0nwnORXAS3sUylMtnwJnkzy0q8PuFJAGkvip/2gAe3R1EI67lApcAeB0kud3efSdA9JAcvvYY7x5ZiseIfCwArkKfBPAOwGcQfKPuUHa+vUCyMpkJG0C8Njmb1cA8edhBdZT4AYA0Rm9EMDmvveq7x2QtVSQZFAMyGoFbgww+rhKbCT9KADxuWEFxqqAARlrZZzXKBQwIKMog5MYqwIGZKyVcV6jUMCAjKIMTmKsChiQsVbGeY1CAQMyijI4ibEqYEDGWhnnNQoFDMgoyuAkxqqAARlrZZzXKBQwIKMog5MYqwIGZKyVcV6jUMCAjKIMTmKsChiQsVbGeY1CAQMyijI4ibEqYEDGWhnnNQoFDMgoyuAkxqqAARlrZZzXKBT4M/pTXlAj+x8uAAAAAElFTkSuQmCC";
		html+= "<div id='plugin_coolhii_analysis_vip_movie_box'>";
		html+= "<div class='plugin_item jump_analysis_website' title='VIP视频破解，电视剧可自由选集'><img src='"+vipImgBase64+"'></div>";
		html+= "<div class='plugin_item jump_sheji_website' title='PPT、字体、简历、美图免费下载'><img src='"+shejiImgBase64+"'></div>";
		html+= "<div class='plugin_item plugin_item_tv jump_tv_website' title='高清在线电视，剧情不错过'><img src='"+tvImBase64+"'></div>";
		html+= "</div>";
		$("body").append(html);
	};
	coolhiiVIPVideo.operation=function(){
		$("body").on("click", "#plugin_coolhii_analysis_vip_movie_box .jump_analysis_website", function(){
			var jumpWebsite=coolhiiVIPVideo.analysisWebsite+window_url;
			GM_openInTab(jumpWebsite, { active: true });
		});
		$("body").on("click", "#plugin_coolhii_analysis_vip_movie_box .jump_sheji_website", function(){
			GM_openInTab("https://www.sjtiantang.com/", { active: true });
		});
		$("body").on("click", "#plugin_coolhii_analysis_vip_movie_box .plugin_item_tv", function(){
			GM_openInTab("http://vip.coolhii.com/video/tv/", { active: true });
		});
	};
	coolhiiVIPVideo.paramsSelectedInit=function(){
		var episodeList=[];
		var episodeObj = {
			"websiteTitle":"",
			"episodeList":episodeList,
			"originVideoUrl":""
		};
		GM_setValue("episodeObj",episodeObj);
		return episodeObj;
	};
    coolhiiVIPVideo.getSelected=function(){
		if(website_host==="v.qq.com"){
			setInterval(function(){ //每100ms,检测一次集数的变化
				var episodeObj = coolhiiVIPVideo.paramsSelectedInit();
				var episodeList = episodeObj.episodeList;
				var $mod_episode = $(".mod_episode");
				try{
					if($mod_episode.attr("data-tpl")=="episode"){
						$mod_episode.find(".item").each(function(){
							var $a = $(this).find("a");
							var href = $a.attr("href");
							if(!!href){
								href = "https://v.qq.com"+href;
								var aText = $a.text();
								aText = aText.replace(/\s/g,"");
	    						episodeList.push({"aText":aText, "href":href, "description":""});
							}
						});
					}
				}catch(e){}
				//加入油猴缓存
				episodeObj.websiteTitle="qq";
				episodeObj.originVideoUrl=window_url;
				if(episodeList.length!=0){
					episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},100);
		};
		if(website_host==="www.iqiyi.com"){
			var episodeObj = coolhiiVIPVideo.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			var $i71playpagesdramalist = $("div[is='i71-play-ab']");
			if($i71playpagesdramalist.length!=0){
				var data =  $i71playpagesdramalist.attr(":page-info");
				if(!!data){
					var dataJson = JSON.parse(data);
					var barTotal = 1;
					var albumId = dataJson.albumId;
					console.log("albumId=",albumId);
					try{
						var $barlis = $(".qy-episode-tab").find(".bar-li");
						barTotal = $barlis.length;
						if(barTotal==0) barTotal=1;
					}catch(e){}
					//获取具体数据
					for(var page=1; page<=barTotal;  page++){
						console.log("^^^^^^^^^^^^^^^^^^^^^^^^^","page=",page);
						try{
							GM_xmlhttpRequest({
								url: "https://pcw-api.iqiyi.com/albums/album/avlistinfo?aid="+albumId+"&page="+page+"&size=30",
							  	method: "GET",
							  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
							  	onload: function(response) {
									var status = response.status;
									if(status==200||status=='200'){
										var serverResponseJson = JSON.parse(response.responseText);
										var code = serverResponseJson.code;
										if(code=="A00000"){
											var serverEpsodelist = serverResponseJson.data.epsodelist;
											//console.log(serverEpsodelist)
											for(var i=0; i<serverEpsodelist.length; i++){
												var aText = serverEpsodelist[i].order;
												var href = serverEpsodelist[i].playUrl;
												var description = serverEpsodelist[i].subtitle;
												episodeList.push({"aText":aText, "href":href, "description":description});
											}
											//加入油猴缓存
											if(episodeList.length!=0){
												episodeObj.episodeList=episodeList;
											}
											episodeObj.websiteTitle="iqiyi";
											episodeObj.originVideoUrl=window_url;
											GM_setValue("episodeObj",episodeObj);
										}
									}
							  	}
							});
						}catch(err){}
						setTimeout(function(){}, 500);
					}
					episodeObj.websiteTitle="iqiyi";
					episodeObj.originVideoUrl=window_url;
					GM_setValue("episodeObj",episodeObj);
				}
			}
		};
		if(website_host==="www.mgtv.com"){
			var episodeObj = coolhiiVIPVideo.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			setTimeout(function(){
				$("body").find(".aside-tabbox").each(function(){
					$(this).find("li").each(function(){
	    				var $a = $(this).find("a");
						var href = $a.attr("href");
						var aText = $(this).text();
						if(!!href && aText.indexOf("预告")==-1){
							href = "https://www.mgtv.com"+href;
							aText = aText.replace("VIP","");
							episodeList.push({"aText":aText, "href":href, "description":""});
						}
					});
				});
				//加入油猴缓存
				episodeObj.websiteTitle="mgtv";
				episodeObj.originVideoUrl=window_url;
				if(episodeList.length!=0){
					episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},1000);
		};
		if(website_host==="v.youku.com"){
			function youku_select(){
				var episodeObj = coolhiiVIPVideo.paramsSelectedInit();
				var episodeList = episodeObj.episodeList;
				$(".anthology-content-scroll").find(".anthology-content").find(".box-item").each(function(){
					var title = $(this).attr("title");
					var href = $(this).attr("href");
					
					var $markText = $(this).find(".mark-text");
					if($markText.length==0 || "预告".indexOf($markText.text)==-1){
						if(!!href){
							var aText = title;
							var arr = aText.split(" ");
							if(arr.length>=2) aText = arr[arr.length-1];
							aText = aText.replace(/[^0-9]/ig,"");
							
							if(!!aText){
								episodeList.push({"aText":aText, "href":href, "description":title});
								//console.log({"aText":aText, "href":href, "description":title})
							}
						}
					}
				});
				//加入油猴缓存
				episodeObj.websiteTitle="youku";
				episodeObj.originVideoUrl=window_url;
				if(episodeList.length!=0){
	    			episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			}
			youku_select();
			setInterval(function(){
				youku_select();
			}, 600);
		};
		if(website_host==="tv.sohu.com"){
			var episodeObj = coolhiiVIPVideo.paramsSelectedInit();
			var episodeList = episodeObj.episodeList;
			setTimeout(function(){
				var $jlistwrap = $(".j-list-wrap");
				if(!!$jlistwrap){
					$jlistwrap.find("li").each(function(){
						var $a = $(this).find("a");
						if(!!$a){
							var aText = $(this).attr("data-order");
							var href = $a.attr("href");
							var title = $a.attr("data-title");
							if(!!aText && !!href){
								href = "https"+href;
								episodeList.push({"aText":aText, "href":href, "description":title});
								//console.log({"aText":aText, "href":href, "description":title});
							}
						}
					});
				}
				//加入油猴缓存
				episodeObj.websiteTitle="sohu";
				episodeObj.originVideoUrl=window_url;
				if(episodeList.length!=0){
	    			episodeObj.episodeList=episodeList;
	    		}
				GM_setValue("episodeObj",episodeObj);
			},1000);
		};
    };
	//支持电视剧选集
	coolhiiVIPVideo.movieWebsitesPlayersSelected=function(){
		if((website_host=="vip.coolhii.com" && window_url.indexOf("vip.coolhii.com/video/s")!=-1)){
			var innerCss= 
				`
				#plugin_coolhii_episode_box{position:fixed; top:170px; left:10px; height:60%; overflow:auto;}
				#plugin_coolhii_episode_box >a{display:inline-block;width:25px;height:25px;text-align:center;line-height:25px;border:1px dashed #000;color:#000;margin:5px;text-decoration:none;cursor:pointer;}
				#plugin_coolhii_episode_box >a:hover{border:1px dashed #FA749A;color:#FA749A;}
				#plugin_coolhii_episode_box >.active{border:1px dashed #FA749A;color:#FA749A;}
				#plugin_coolhii_episode_box >.tip{text-align:center;padding:5px;}
				@media (max-width: 767px) {#plugin_coolhii_episode_box{display:none;}}
				`;
				
			$("body").prepend("<style>"+innerCss+"</style>");
			var episodeObj = GM_getValue("episodeObj");
			if(!!episodeObj){
				var episodeList = episodeObj.episodeList;
				if(!!episodeList && episodeList.length!=0){
					episodeList.sort((d1, d2)=>{  //排序
						var aText1 = d1.aText;
						var aText2 = d2.aText;
						var aText1Value = parseInt(aText1);
						var aText2Value = parseInt(aText2);
						if(isNaN(aText1Value) || isNaN(aText2Value)){
							return 0;
						}else{
							return aText1Value-aText2Value;
						}
					});
					var websiteTitle = episodeObj.websiteTitle;
					var currentvideourl = GM_getValue("currentvideourl");
					var html = "<div id='plugin_coolhii_episode_box'>";
					html += "<div class='tip'><b>电视剧点击集数，可自由选集</b></div>";
					var waiturl="";
					var aclass="";
					for(var i=0; i<episodeList.length; i++){
						waiturl=episodeList[i].href;
						aclass="plugin-episode";
						if(window_url.indexOf(waiturl)!=-1 || (currentvideourl==waiturl && websiteTitle=="iqiyi")){
							aclass = aclass +" "+"active";
						}
						html+= "<a class='"+aclass+"' data-href='"+waiturl+"' title='"+episodeList[i].description+"'>"+episodeList[i].aText+"</a>";
						if((i+1)%6==0){
							html+= "<br>";
						}
					}
					var originVideoUrl=episodeObj.originVideoUrl;
					if(!!originVideoUrl){
						html += "<div class='origin-video-url'><b>来源视频链接：<a href='"+originVideoUrl+"'>点我返回</a><b></div>";
					}
					html += "</div>";
					$("body").append(html);
				}
			}
			$("body").on("click", ".plugin-episode", function(){
				var href=$(this).data("href");
				if(!!href){
					href = coolhiiVIPVideo.analysisWebsite+href;
					window.location.href=href;
				}
			});			
		}
	}
	coolhiiVIPVideo.start=function(){
    	if(coolhiiVIPVideo.judgeVipWebsite() && window.top==window.self){
    		coolhiiVIPVideo.addStyle();
			coolhiiVIPVideo.generateHtml();
			coolhiiVIPVideo.operation();
    		coolhiiVIPVideo.getSelected();
    	}
    	coolhiiVIPVideo.movieWebsitesPlayersSelected();
    };
	coolhiiVIPVideo.start();
   	if(coolhiiVIPVideo.judgeVipWebsite()){
   		return false;
   	};
   	
   	//福利放送
   	var welfareGet={};
   	welfareGet.websiteurl="http://vip.coolhii.com/video/s/welfare";
   	welfareGet.judge=function(){
   		if(website_host=="vip.coolhii.com"){
   			return true;
   		}	
   		return false;
   	}
   	welfareGet.get=function(){
   		if(welfareGet.judge() && window.top==window.self){
			GM_xmlhttpRequest({
				url: welfareGet.websiteurl,
			  	method: "GET",
			  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
			  	onload: function(response) {
					var status = response.status;
					if(status==200||status=='200'){
						var serverResponseJson = JSON.parse(response.responseText);
						var data = serverResponseJson.data;
						if(!!data){
							var $tampermonkeydataarea = $("#tampermonkey-data-area");
							$tampermonkeydataarea.empty();
							$tampermonkeydataarea.html(data);
						}
					}
			  	}
			});
   		}
   	};
   	welfareGet.get();
   	   	
   	//音乐下载：无损音乐、封面、歌词
	var musicvip={};
	musicvip.operation=function(){
		var reWY = /163(.*)song/i;
		var reQQ = /QQ(.*)song/i;
		var reKG = /kugou(.*)song/i;
		
		var ayaMusicWebsite = "http://mctool.cn/music/?page=audioPage&type=migu&name=";
		var ayaMusicTitle = "http://tool.liumingye.cn/music/?page=audioPage&type=migu&name=";
		var ayaMusicWebsite2 = "https://music.liuzhijin.cn/?url=";
		var ayaMusicTitle2 = "https://music.liuzhijin.cn/?name=@name@&type=netease";
		var vipBtn = '<div>';
		 	vipBtn += '<a target="_blank" id="ayasongurl-1" style="margin:5px 10px 5px 0px;display:inline-block;padding:4px 8px;background-color:#FF410F;color:#FFF;vertical-align:bottom;text-decoration:none;font-size:13px;"><b>免费下载（线路1）</b></a>';
			vipBtn += '<a target="_blank" id="ayasongtitle-1" style="margin:5px 0px;display:inline-block;padding:4px 8px;background-color:#FF410F;color:#FFF;vertical-align:bottom;text-decoration:none;font-size:13px;"><b>歌名搜索（线路1）</b></a>';
			vipBtn += '</div>';
			vipBtn += '<div>';
			vipBtn += '<a target="_blank" id="ayasongurl-2" style="margin:5px 10px 5px 0px;display:inline-block;padding:4px 8px;background-color:#FF410F;color:#FFF;vertical-align:bottom;text-decoration:none;font-size:13px;"><b>免费下载（线路2）</b></a>';
			vipBtn += '<a target="_blank" id="ayasongtitle-2" style="margin:5px 0px;display:inline-block;padding:4px 8px;background-color:#FF410F;color:#FFF;vertical-align:bottom;text-decoration:none;font-size:13px;"><b>歌名搜索（线路2）</b></a>';
			vipBtn += '</div>';
		if(reWY.test(window_url)){
			var $title = $('.u-icn-37');
		    $title.parent('.hd').after(vipBtn);
		    var titleText = $(".tit").text();
		    $('#ayasongurl-1').attr('href',ayaMusicWebsite + encodeURIComponent(window.location.href.replace('://music.163.com', "://music.163.com/#")));
		    $('#ayasongtitle-1').attr("href", ayaMusicTitle + encodeURIComponent(titleText));
		    $('#ayasongurl-2').attr('href', ayaMusicWebsite2 + encodeURIComponent(window.location.href.replace('://music.163.com', "://music.163.com/#")));
		    $('#ayasongtitle-2').attr("href", encodeURIComponent(ayaMusicTitle2.replace("@name@", titleText)));
		    
		}else if(reQQ.test(window_url)){
			var $title = $('.data__name_txt');
			var titleText = $(".data__name_txt").text();
		    $title.parent('.data__name').after(vipBtn);
		    $('#ayasongurl-1').attr('href',ayaMusicWebsite + encodeURIComponent(window.location.href));
		    $('#ayasongtitle-1').attr("href", ayaMusicTitle + encodeURIComponent(titleText));
		    $('#ayasongurl-2').attr('href', ayaMusicWebsite2 + encodeURIComponent(window.location.href));
		    $('#ayasongtitle-2').attr("href", ayaMusicTitle2.replace("@name@", titleText));
		    
		}else if(reKG.test(window_url)){
			setTimeout(function(){
				var $title = $('.audioName');
				$title.parent('.songName').after(vipBtn);
				var titleText = $(".audioName").text();
				$("#ayasongurl-1").attr("href", ayaMusicWebsite + encodeURIComponent(window.location.href));
		    	$('#ayasongtitle-1').attr("href", ayaMusicTitle + encodeURIComponent(titleText));
		    	$('#ayasongurl-2').attr('href', ayaMusicWebsite2 + encodeURIComponent(window.location.href));
		    	$('#ayasongtitle-2').attr("href", ayaMusicTitle2.replace("@name@", titleText));
			},1200);
		}
	};
	musicvip.start=function(){
		if(window_url.indexOf("music.163.com")!=-1 || window_url.indexOf("y.qq.com")!=-1 || window_url.indexOf("www.kugou.com")!=-1){
			musicvip.operation();
		}
	};
	musicvip.start();
	
	//必应背景下载
	var biying={};
	biying.getBackgroundImage = function(){
		var backgroundImageurl = $("#bgDiv").css("background-image");
		return backgroundImageurl.replace("url(\"","").replace("\")","");
	};
	biying.addHtml = function(backgroundImageurl){
		$("#plugin-script-downloadimage").remove();
		var downloadimage ="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAEzElEQVR4Xu2bW8hVRRTH/38IijKDMrQIie5ETxVGl4eil+69lJEPmWIU2QWi6OshCAzSoIRCI7sXZGhBSWhFgUQaUfoS+dCFouh+gbAeguAfK9bYtNlnz+zL+Q5yZmBz+PaeWZffXjOzZp3zEVPeOOX+owAoETDlBMoUmFQASDoBwGcAfgawnOTrk7BlYhEgaSuAi93pzSQXTxsARQ5vJ3lBATABApOcAiUCyhT4j0BZA8oiWHaBsg2WPGACacDk6gGSSh5Q8oCSB+wjUBKhkgiVRKgkQiURKonQBAiUitCQ0CVZldequ7tJPtoku20qLOlWAKcAeJPklqHsHjQCJP0K4HA37iWS144ytA0ASZsAXO2ydpE8c1YASLoPwA0AtgG4n+RXibf6JYBjoz4vkLyubkwugIrzJiqZNUo6CIBBOw7AyyTNj9rWGAEVI5eRfDYBwN6SKY7bMySXV8flAKhx3sQsJrk5YceDAO7yPp+QPK01AElnAPgoGriW5B2p0JNUB2EDyRvjsSkAXZ03HZLeA3Cu69tLcm4XAEcB+C4a+ArJq1IA3IA6COtI3hLGNwHo47zr/xhAeOufkjy5NQAXFBctPiS5KAdAA4R9UTQKQF/nXfc3AI5xWxvXjNQa8C2Ao13QjyQX5AJogLCG5EwdgCGcd717AcxxWzeSXNI1AmwNsLUgtHkkbavLbiPWhFUA7o2EbPevycNWFx4lF7yqIZKOBPBTdP8hknd2BbAOwM3R4KUkn8/23juOgBCLMQDnV+S2dt7fvtlrdoe2hOTGrgAuBPB2NHgTyWvaAmiYDqNEdXLe9dgPLS6NBM8laVOitiUzQUkWThZW1v4EsJDkb2OE0Md5s9OStYPdvm0kL2myNQfAEwBWREJWklzfBUBGJHR2fkT435Y6k+QAsHz+xcjhLwCcTdJ+29OpjVgT+jpvb/99AMdHRp1I8vNeEeBkbR2w9SC01STv6eS9D3IId/uftjU2prcpXZIeADAT9ftf4tV5DXAAF/mBKMj5C8A5JHenDJuN55JOB7ATwIGu7w8AZ5Hck9KfnAJBgKQNfjIMt3aQPC+lYNzPJR0A4I1KhP6bbOXobgPgJAA7AMyLBHfeFnOMy+kj6WkAy6K+P/jb/zpnfDYAnwrVJMNuryD5VI6yoftIio+9Qfz1JJ/L1dUKgEOobot2+/LZ/qWnpMcA3FRxdIbkmlznrV9rAA5hFwBbeOJ2O8lH2ijv2nfEoWkLySvbyuwEwCHER+Wg93E75PTJEZockDQfgBVbq4cmkOzkS6dB0c7wGoArKkZbovRwn2yxCkGSpbYrAVhBZWHluVWg4xNrqyDoBcAjwZKZ1TVa7YS3FsBWkn+3sso7S7IKs5XZzfm6ut6TJK1o27n1BuAQljqEuoKJHabetXo+gFdJ/pII8yP8NGcnOrsOqelvW92qIaJsEAAOwULTtkl7W6EaU+ernSh/jy7rc1h01Tkc5FiGZ2f99SSz9vlUaAwGIFoXTo1ApPS3eR4cT6a3bYQODiACYf8RYl+VhauNXaGvHZDeAvAOSfvSZfA2NgCxpZIOBXCZ1xetyGol9/BpXb/3Enz4/MAXT5suY22zAmCsHvQUXgD0BLjfDy8RsN+/wp4OTH0E/APb2Chfnm53kAAAAABJRU5ErkJggg==";
		var html = '<a id="plugin-script-downloadimage" title="点击下载背景" href="'+backgroundImageurl+'" target="_blank">'+
						'<div style="overflow: hidden;width: 40px;height: 40px;line-height:40px;text-align:center;;margin: 0 10px;background-position-x: 0;"><img style="width:100%;" src="'+downloadimage+'" /></div>'+
					'</a>';
		$("#sh_rdiv").append(html);
	};
	biying.start = function(){
		var $that = this;
		if(window.location.href.indexOf("bing.com")!=-1){
			setInterval(function(){
				var backgroundImageurl = $that.getBackgroundImage();
				$that.addHtml(backgroundImageurl);
			},500);
		}
	};
	biying.start();
	
	//领券
	var goodsCoupon={};
	goodsCoupon.getPlatform=function(){
		var couponUrl = window.location.href;
		var platform="";
		if(couponUrl.indexOf("suning.com")!=-1){
			platform = "suning";
		}else if(couponUrl.indexOf("detail.tmall")!=-1){
			platform = "tmall";
		}else if(couponUrl.indexOf("item.taobao.com")!=-1){
			platform = "taobao";
		}else if(couponUrl.indexOf("item.jd.com")!=-1){
			platform = "jd";
		}else if(couponUrl.indexOf("detail.vip.com")!=-1){
			platform = "vpinhui";
		}else if(couponUrl.indexOf("mobile.yangkeduo.com")!=-1){
			platform = "pdd";
		}
		return platform;
	}
	goodsCoupon.filterStr = function(str){
		if(!str) return "";
		str = str.replace(/\t/g,"");
		str = str.replace(/\r/g,"");
		str = str.replace(/\n/g,"");
		str = str.replace(/\+/g,"%2B");//"+"
		str = str.replace(/\&/g,"%26");//"&"
		str = str.replace(/\#/g,"%23");//"#"
		return encodeURIComponent(str)
	};
	goodsCoupon.getGoodsData=function(platform){
		var goodsId = "";
		var goodsName = "";
		var websiteUrl = window.location.href;
		if(platform=="taobao"){
			goodsId = this.getQueryString("id");
			goodsName=$(".tb-main-title").text();
			
		}else if(platform=="tmall"){
			goodsId = this.getQueryString("id");
			goodsName=$(".tb-detail-hd").text();
			
		}else if(platform=="jd"){
			goodsName=$("div.sku-name").text();
			goodsId = this.getQueryStringByUrl(websiteUrl);
			
		}else if(platform=="suning"){
			var text = $("#itemDisplayName").text();
			if(!!text){
				text = text.replace("苏宁超市","");
				text = text.replace("自营","");
			}
			goodsName=text;
			goodsId = this.getQueryStringByUrl(websiteUrl);
			
		}else if(platform=="vpinhui"){
			goodsId = this.getQueryStringByUrl(websiteUrl).replace("detail-","");
			goodsName = $(".pib-title-detail").text();
			
		}else if(platform=="pdd"){
			goodsId = this.getQueryString("goods_id");
			goodsName = $(".enable-select").text();
		}
		var data={"goodsId":goodsId, "goodsName":this.filterStr(goodsName)}
		return data;
	};
	goodsCoupon.createHtml = function(platform, goodsId, goodsName){
		if(!platform || !goodsId) return;
		var goodsCouponUrl = "https://www.whatbuytoday.com/api/plugin/hit/v2";
		if(platform!="vpinhui"){
			goodsCouponUrl = goodsCouponUrl+"?platform="+platform+"&id="+goodsId+"&q="+goodsName;
		}else{
			var vip = goodsId.split("-");
			var vaddition = vip[0];
			var vid = vip[1];
			goodsCouponUrl = goodsCouponUrl+"?platform="+platform+"&id="+vid+"&q="+goodsName+"&addition="+vaddition;
		}		
		GM_xmlhttpRequest({
			url: goodsCouponUrl,
		  	method: "GET",
		  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
		  	onload: function(response) {
				var status = response.status;
				if(status==200||status=='200'){
					var serverResponseJson = JSON.parse(response.responseText);
					var data = serverResponseJson.data;
					var cssText = data.css;
					var htmlText = data.html;
					var handler = data.handler;
					if(!cssText || !htmlText || !handler){
						return;
					}
					$("body").prepend("<style>"+cssText+"</style>");
					var handlers = handler.split("@");
					for(var i=0; i<handlers.length; i++){
						var $handler = $(""+handlers[i]+"");
						if(platform=="taobao"){
							$handler.parent().after(htmlText);
						}else if(platform=="tmall"){
							$handler.parent().after(htmlText);
						}else if(platform=="jd"){
							$handler.after(htmlText);
						}else if(platform=="suning"){
							$handler.parent().after(htmlText);
						}else if(platform=="vpinhui"){
							$handler.parent().after(htmlText);
						}else if(platform=="pdd"){
							$handler.after(htmlText);
						}					
					}
				}
		  	}
		});
	};
	goodsCoupon.getQueryString = function(tag) {
		var t = new RegExp("(^|&)" + tag + "=([^&]*)(&|$)");
		var a = window.location.search.substr(1).match(t);
		if (a != null) return a[2];
		return "";
	};
	goodsCoupon.getQueryStringByUrl = function(url) {
		if(url.indexOf("?")!=-1){
			url = url.split("?")[0]
		}
		if(url.indexOf("#")!=-1){
			url = url.split("#")[0]
		}
		var splitText = url.split("/");
		var idText = splitText[splitText.length-1];
		idText = idText.replace(".html","");
		return idText;
	};
	goodsCoupon.start = function(){
		var platform = this.getPlatform();
		if(!platform) return;
		var delayMS = 0;
		if(platform=="vpinhui"){ //唯品会采用了异步加载
			var vipInterval = setInterval(function(){
				if($(".pib-title-detail").length!=0 || delayMS>=1200){
					var goodsData = goodsCoupon.getGoodsData(platform);
					goodsCoupon.createHtml(platform, goodsData.goodsId, goodsData.goodsName);
					clearInterval(vipInterval)
				}
				delayMS+=100;
			},100);
		}else{
			var goodsData = goodsCoupon.getGoodsData(platform);
			goodsCoupon.createHtml(platform, goodsData.goodsId, goodsData.goodsName);
		}
	};	
	goodsCoupon.start();
})();

///知乎视频下载，避免重复造轮子
///代码作者：王超
///版本：v1.18
///greasyfork地址：https://greasyfork.org/zh-CN/scripts/39206
(async () => {
    if (window.location.host == 'www.zhihu.com') return;

    const playlistBaseUrl = 'https://lens.zhihu.com/api/videos/';
    //const videoBaseUrl = 'https://video.zhihu.com/video/';
    const videoId = window.location.pathname.split('/').pop(); // 视频id
    const menuStyle = 'transform:none !important; left:auto !important; right:-0.5em !important;';
    const playerId = 'player';
    const coverSelector = '#' + playerId + ' > div:first-child > div:first-child > div:nth-of-type(2)';
    const controlBarSelector = '#' + playerId + ' > div:first-child > div:first-child > div:last-child > div:last-child > div:first-child';
    const svgDownload = '<path d="M9.5,4 H14.5 V10 H17.8 L12,15.8 L6.2,10 H9.5 Z M6.2,18 H17.8 V20 H6.2 Z"></path>';
    let player = document.getElementById(playerId);
    let resolutionMap = {'标清': 'sd', '高清': 'ld', '超清': 'hd'};
    let videos = []; // 存储各分辨率的视频信息
    let downloading = false;

    function getBrowerInfo() {
        let browser = (function (window) {
            let document = window.document;
            let navigator = window.navigator;
            let agent = navigator.userAgent.toLowerCase();
            // IE8+支持.返回浏览器渲染当前文档所用的模式
            // IE6,IE7:undefined.IE8:8(兼容模式返回7).IE9:9(兼容模式返回7||8)
            // IE10:10(兼容模式7||8||9)
            let IEMode = document.documentMode;
            let chrome = window.chrome || false;
            let system = {
                // user-agent
                agent: agent,
                // 是否为IE
                isIE: /trident/.test(agent),
                // Gecko内核
                isGecko: agent.indexOf('gecko') > 0 && agent.indexOf('like gecko') < 0,
                // webkit内核
                isWebkit: agent.indexOf('webkit') > 0,
                // 是否为标准模式
                isStrict: document.compatMode === 'CSS1Compat',
                // 是否支持subtitle
                supportSubTitle: function () {
                    return 'track' in document.createElement('track');
                },
                // 是否支持scoped
                supportScope: function () {
                    return 'scoped' in document.createElement('style');
                },

                // 获取IE的版本号
                ieVersion: function () {
                    let rMsie = /(msie\s|trident.*rv:)([\w.]+)/;
                    let match = rMsie.exec(agent);
                    try {
                        return match[2];
                    } catch (e) {
                        return IEMode;
                    }
                },
                // Opera版本号
                operaVersion: function () {
                    try {
                        if (window.opera) {
                            return agent.match(/opera.([\d.]+)/)[1];
                        }
                        else if (agent.indexOf('opr') > 0) {
                            return agent.match(/opr\/([\d.]+)/)[1];
                        }
                    } catch (e) {
                        return 0;
                    }
                }
            };

            try {
                // 浏览器类型(IE、Opera、Chrome、Safari、Firefox)
                system.type = system.isIE ? 'IE' :
                    window.opera || (agent.indexOf('opr') > 0) ? 'Opera' :
                        (agent.indexOf('chrome') > 0) ? 'Chrome' :
                            //safari也提供了专门的判定方式
                            window.openDatabase ? 'Safari' :
                                (agent.indexOf('firefox') > 0) ? 'Firefox' :
                                    'unknow';

                // 版本号
                system.version = (system.type === 'IE') ? system.ieVersion() :
                    (system.type === 'Firefox') ? agent.match(/firefox\/([\d.]+)/)[1] :
                        (system.type === 'Chrome') ? agent.match(/chrome\/([\d.]+)/)[1] :
                            (system.type === 'Opera') ? system.operaVersion() :
                                (system.type === 'Safari') ? agent.match(/version\/([\d.]+)/)[1] :
                                    '0';

                // 浏览器外壳
                system.shell = function () {
                    if (agent.indexOf('edge') > 0) {
                        system.version = agent.match(/edge\/([\d.]+)/)[1] || system.version;
                        return 'Edge';
                    }
                    // 遨游浏览器
                    if (agent.indexOf('maxthon') > 0) {
                        system.version = agent.match(/maxthon\/([\d.]+)/)[1] || system.version;
                        return 'Maxthon';
                    }
                    // QQ浏览器
                    if (agent.indexOf('qqbrowser') > 0) {
                        system.version = agent.match(/qqbrowser\/([\d.]+)/)[1] || system.version;
                        return 'QQBrowser';
                    }
                    // 搜狗浏览器
                    if (agent.indexOf('se 2.x') > 0) {
                        return '搜狗浏览器';
                    }

                    // Chrome:也可以使用window.chrome && window.chrome.webstore判断
                    if (chrome && system.type !== 'Opera') {
                        let external = window.external;
                        let clientInfo = window.clientInformation;
                        // 客户端语言:zh-cn,zh.360下面会返回undefined
                        let clientLanguage = clientInfo.languages;

                        // 猎豹浏览器:或者agent.indexOf("lbbrowser")>0
                        if (external && 'LiebaoGetVersion' in external) {
                            return 'LBBrowser';
                        }
                        // 百度浏览器
                        if (agent.indexOf('bidubrowser') > 0) {
                            system.version = agent.match(/bidubrowser\/([\d.]+)/)[1] ||
                                agent.match(/chrome\/([\d.]+)/)[1];
                            return 'BaiDuBrowser';
                        }
                        // 360极速浏览器和360安全浏览器
                        if (system.supportSubTitle() && typeof clientLanguage === 'undefined') {
                            let storeKeyLen = Object.keys(chrome.webstore).length;
                            let v8Locale = 'v8Locale' in window;
                            return storeKeyLen > 1 ? '360极速浏览器' : '360安全浏览器';
                        }
                        return 'Chrome';
                    }
                    return system.type;
                };

                // 浏览器名称(如果是壳浏览器,则返回壳名称)
                system.name = system.shell();
                // 对版本号进行过滤过处理
                // System.version = System.versionFilter(System.version);

            } catch (e) {
                // console.log(e.message);
            }

            return system;

        })(window);

        if (browser.name == undefined || browser.name == '') {
            browser.name = 'Unknown';
            browser.version = 'Unknown';
        }
        else if (browser.version == undefined) {
            browser.version = 'Unknown';
        }
        return browser;
    }

    function fetchRetry(url, options = {}, times = 1, delay = 1000, checkStatus = true) {
        return new Promise((resolve, reject) => {
            // fetch 成功处理函数
            function success(res) {
                if (checkStatus && !res.ok) {
                    failure(res);
                }
                else {
                    resolve(res);
                }
            }

            // 单次失败处理函数
            function failure(error) {
                times--;

                if (times) {
                    setTimeout(fetchUrl, delay);
                }
                else {
                    reject(error);
                }
            }

            // 总体失败处理函数
            function finalHandler(error) {
                throw error;
            }

            function fetchUrl() {
                return fetch(url, options)
                    .then(success)
                    .catch(failure)
                    .catch(finalHandler);
            }

            fetchUrl();
        });
    }

    // 下载指定url的资源
    async function downloadUrl(url, name = (new Date()).valueOf() + '.mp4') {
        let browser = getBrowerInfo();

        // Greasemonkey 需要把 url 转为 blobUrl
        if (GM_info.scriptHandler == 'Greasemonkey') {
            let res = await fetchRetry(url);
            let blob = await res.blob();
            url = URL.createObjectURL(blob);
        }

        // Chrome 可以使用 Tampermonkey 的 GM_download 函数绕过 CSP(Content Security Policy) 的限制
        if (window.GM_download) {
            GM_download({url, name});
        }
        else {
            // firefox 需要禁用 CSP, about:config -> security.csp.enable => false
            let a = document.createElement('a');
            a.href = url;
            a.download = name;
            // a.target = '_blank';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);

            setTimeout(function () {
                URL.revokeObjectURL(url);
            }, 100);
        }
    }

    function humanSize(size) {
        let n = Math.log(size) / Math.log(1024) | 0;
        return (size / Math.pow(1024, n)).toFixed(0) + ' ' + (n ? 'KMGTPEZY'[--n] + 'B' : 'Bytes');
    }

    if (!player) return;

    // 获取视频信息
    const res = await fetchRetry(playlistBaseUrl + videoId, {
        headers: {
            'referer': 'refererBaseUrl + videoId',
            'authorization': 'oauth c3cef7c66a1843f8b3a9e6a1e3160e20' // in zplayer.min.js of zhihu
        }
    }, 3);
    const videoInfo = await res.json();

    // 获取不同分辨率视频的信息
    for (let [key, video] of Object.entries(videoInfo.playlist)) {
        video.name = key;

        if (!videos.find(v => v.width == video.width)) {
            videos.push(video);
        }
    }

    // 按分辨率大小排序
    videos = videos.sort(function (v1, v2) {
        return v1.width == v2.width ? 0 : (v1.width > v2.width ? 1 : -1);
    }).reverse();

    document.addEventListener('DOMNodeInserted', (evt) => {
        let domControlBar = evt.relatedNode.querySelector(':scope > div:last-child > div:first-child');
        if (!domControlBar || domControlBar.querySelector('.download')) return;

        let domFullScreenBtn = domControlBar.querySelector(':scope > div:nth-last-of-type(1)');
        let domResolutionBtn = domControlBar.querySelector(':scope > div:nth-last-of-type(3)');
        let domDownloadBtn, defaultResolution, buttons;
        if (!domFullScreenBtn || !domFullScreenBtn.querySelector('button')) return;

        // 克隆分辨率菜单或全屏按钮为下载按钮
        domDownloadBtn = (domResolutionBtn && (domResolutionBtn.className == domFullScreenBtn.className))
            ? domResolutionBtn.cloneNode(true)
            : domFullScreenBtn.cloneNode(true);

        defaultResolution = domDownloadBtn.querySelector('button').innerText;

        // 生成下载按钮图标
        domDownloadBtn.querySelector('button:first-child').outerHTML = domFullScreenBtn.cloneNode(true).querySelector('button').outerHTML;
        domDownloadBtn.querySelector('svg').innerHTML = svgDownload;
        domDownloadBtn.className = domDownloadBtn.className + ' download';

        buttons = domDownloadBtn.querySelectorAll('button');

        // button 元素添加对应的下载地址
        buttons.forEach(dom => {
            let video = videos.find(v => v.name == resolutionMap[dom.innerText || defaultResolution]);
            video = video || videos[0];
            dom.dataset.video = video.play_url;
            if (dom.innerText) {
                (dom.innerText = `${dom.innerText} (${humanSize(video.size)})`);
            }
            else if (buttons.length == 1) {
                dom.nextSibling.querySelector('div').innerText = humanSize(video.size);
            }
        });

        // 鼠标事件 - 显示菜单
        domDownloadBtn.addEventListener('pointerenter', () => {
            let domMenu = domDownloadBtn.querySelector('div:nth-of-type(1)');
            if (domMenu) {
                domMenu.style.cssText = menuStyle + 'opacity:1 !important; visibility:visible !important';
            }
        });

        // 鼠标事件 - 隐藏菜单
        domDownloadBtn.addEventListener('pointerleave', () => {
            let domMenu = domDownloadBtn.querySelector('div:nth-of-type(1)');
            if (domMenu) {
                domMenu.style.cssText = menuStyle;
            }
        });

        // 鼠标事件 - 选择菜单项
        domDownloadBtn.addEventListener('pointerup', event => {
            if (downloading) {
                alert('当前正在执行下载任务，请等待任务完成。');
                return;
            }

            let e = event.srcElement || event.target;

            while (e.tagName != 'BUTTON') {
                e = e.parentNode;
            }

            downloadUrl(e.dataset.video);
        });

        // 显示下载按钮
        domControlBar.appendChild(domDownloadBtn);

    });
})();