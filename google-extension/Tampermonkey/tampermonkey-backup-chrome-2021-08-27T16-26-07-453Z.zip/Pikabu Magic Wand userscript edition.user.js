// ==UserScript==
// @name         Pikabu Magic Wand userscript edition
// @namespace    http://tampermonkey.net/
// @icon         https://shitcopikabu.strangled.net/icon.png
// @version      0.0.2
// @description  Разудаление комментариев
// @author       Melhov Anton
// @updateURL    https://openuserjs.org/install/shitcopikabu/Pikabu_Magic_wand_userscript_edition.user.js
// @homepage     https://vk.com/id59967447
// @homepage     https://vk.com/shitcopikabu
// @homepage     https://vk.com/klubnikapikabu
// @require      https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @require      https://cdn.jsdelivr.net/npm/jquery.initialize@1.2.0/jquery.initialize.min.js
// @include      http://pikabu.ru/*
// @include      https://pikabu.ru/*
// @include      https://old.pikabu.ru/*
// @connect      https://shitcopikabu.strangled.net
// @license      MIT
// @grant        none
// ==/UserScript==

// ==OpenUserJS==
// @author shitcopikabu
// @collaborator AHTOH874
// ==/OpenUserJS==

(function () {
  'use strict';

  function MagicWand() {
    ///////////////////////////////
    ///         CONFIG          ///
    ///////////////////////////////
    this.backendLocation = "https://shitcopikabu.strangled.net/ajax/";
    this.root = "https://shitcopikabu.strangled.net";
    this.debug = false;

    this.sparklesEmojii = '&#x2728;';
    this.deleteMark = `<span style="color: #888888;">`;
    this.notFoundLabel = `<span style="color: #A88888;">not found</span>`;
    this.tooLateLabel = `<span style="color: #A88888;">too late</span>`;
  }

  MagicWand.prototype = {

    Ajax: function (method, data, success, failure) {
      const self = this;
      if (self.debug) {
        console.log("->", data);
      }

      return $.ajax({
        url: `${self.backendLocation}${method}`,
        type: "POST",
        data: JSON.stringify(data),
        dataType: "json",
        contentType: "application/json",
        headers: {
          "X-Csrf-Token": "not-needed"
        },
        timeout: 300000,

        error: failure,
        success: function (res) {
          if (self.debug) {
            console.log("<-", res);
          }
          success(res);
        },
      });
    },
    init: function () {
      const self = this;
      $.initialize('.b-comment__body,.comment__body', function () {
        let el = $(this);
        let tools = el.find('.b-comment__tools,.comment__tools');

        let content = el.find('.b-comment__content,.comment__content');
        let content_html = "" + content.html();
        if (!content_html.includes(self.deleteMark)) {
          // console.log("not found deletion mark; exiting;");
          return;
        }

        let comment_id = el.parent().attr('data-id');

        let insert = $(`<a ` +
          `style="text-decoration: none;" ` +
          `class="b-comment__tool b-comment__tool-undelete comment__tool" ` +
          `title="Undelete comment" ` +
          `>` +
          `${self.sparklesEmojii}` +
          `</a>`);

        insert.click(function () {

          self.Ajax('undelete', {
            CommentID: parseInt(comment_id),
          }, function (data) {
            const comments = data.comments;
            if (!comments || comments.length != 1) {
              content.html(self.notFoundLabel);
              return;
            }

            let html = comments[0].content_html;
            if (html.includes(self.deleteMark)) {
              content.html(self.tooLateLabel);
              return;
            }

            content.html(html);
          }, function (data, stat, error) {

            const failureLabel = `<span style="color: #A88888;">failure: status=${stat} error=${error}</span>`;
            content.html(failureLabel);
          });

        });

        tools.append(insert);
      });
    }
  };
  $(document).ready(function () {
    const magicWand = new MagicWand();
    magicWand.init();
  });

})();
