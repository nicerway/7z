// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        */C:/Users/*
// @icon         https://www.google.com/s2/favicons?domain=undefined.
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
setTimeout(function(){
      $($("iframe.ui-paper-iframe")[0].contentWindow.document).find(".ui-option-selected").removeClass("ui-option-selected");

        console.log($($("iframe.ui-paper-iframe")[0].contentWindow.document).find("span"))
    }, 1000);
    // Your code here...
})();