// ==UserScript==
// @name         挂课
// @namespace    http://tampermonkey.net/
// @version      1.0
// @match        *://cws.edu-edu.com/*
// @require      https://cdn.bootcdn.net/ajax/libs/jquery/3.5.1/jquery.min.js
// @require      https://cdn.bootcdn.net/ajax/libs/layer/3.1.1/layer.min.js

// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    json = {
accumulativeTime: 1,
backUrl: "https://resgk.edu-xl.com/LearnReturnUrl/LearnReturnUrlIndex",
businessLineCode: "",
catalogId: "424818072851849216",
catalogTitle: "课程导学",
clientCode: "657657",
coursewareCode: "04737_jj",
coursewareName: "C++程序设计（2019版）",
lastTime: 60,
learnRecordId: 0,
userId: "340101199708080538_202110_ahzk365",
userName: "ahzk365",
validTime: 0,
videoTime: null,
   };

$.ajax({
   url: 'https://cws.edu-edu.com/client/learnRecords',
   type: 'POST',
   contentType: "application/json",
   dataType: "json",
   data:JSON.stringify(json),
   success: function( response ) {

   		var time = 5;
		var times = 0;
		var i = setInterval(function(){
			times++;
			if(times >= 5) {
				//clearInterval(i);
				time += 5;
			}
			json = {
								accumulativeTime: time,
			backUrl: "https://resgk.edu-xl.com/LearnReturnUrl/LearnReturnUrlIndex",
			businessLineCode: "",
			catalogId: response.data.catalogId,
			catalogTitle: response.data.catalogTitle,
			clientCode: json.clientCode,
			coursewareCode: response.data.coursewareCode,
			coursewareName: response.data.coursewareName,
			userId: json.userId,
			userName: "ahzk365",
			validTime: 0,
			lastTime: response.data.lastTime,
			learnRecordId: response.data.learnRecordId,
			videoTime: response.data.videoTime,
			}

			if(time>=json.videoTime){
				clearInterval(i);
			}

			$.ajax({
			   url: 'https://cws.edu-edu.com/client/learnRecords',
			   type: 'PUT',
			   contentType: "application/json",
			   dataType: "json",
			   data:JSON.stringify(json),
			   success: function( response ) {
			   	console.log(response)
			   },
			   error: function( response ) {
			   	console.log(response)
			   },
			});

		}, 400)

   },
   error: function( response ) {
   	console.log(response)
   },
});
})();