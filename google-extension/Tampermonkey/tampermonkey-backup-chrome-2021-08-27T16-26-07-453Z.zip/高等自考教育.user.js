// ==UserScript==
// @name         高等自考教育
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://e6.edu-edu.com.cn/exam/student/exam2/dostart/*
// @match        https://e3.edu-edu.com.cn/exam/student/exam2/dostart/*
// @match        https://e4.edu-edu.com.cn/exam/student/exam2/dostart/*
// @match        https://e5.edu-edu.com.cn/exam/student/exam2/dostart/*
// @require      https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js
// @icon         https://www.google.com/s2/favicons?domain=edu-edu.com.cn
// @grant        none
// ==/UserScript==

(function() {
    'use strict';


    setTimeout(function(){
      $($("iframe.ui-paper-iframe")[0].contentWindow.document).find(".ui-option-selected").removeClass("ui-option-selected");

        console.log($($("iframe.ui-paper-iframe")[0].contentWindow.document).find("span"))
    }, 2000);


    // Your code here...
})();